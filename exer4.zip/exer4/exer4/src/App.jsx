import { Card } from "./components/card/index";
import { Item } from "./components/item/index";
import { Label } from "./components/label/index";
import { Button } from "./components/button/index";


export function App() {
  return (
    <>
    <Button/>
      <Card />
      <Item />
      <Label/>
    </>
  );
}

