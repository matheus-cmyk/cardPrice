export function Item() {
    return (
      <ul id="itens">
        <li>Usuario ilimitados</li>
        <li>Suporte 24/7</li>
        <li>CSM Dedicado</li>
        <li>Treinamentos</li>
      </ul>
    );
  }