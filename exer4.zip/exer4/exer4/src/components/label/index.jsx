export function Label() {
    return (
      <>
        <h1>MAIS VANTAJOSO</h1>
        <p>PARA VOCÊ DECOLAR</p>
        <p>
          R$ <strong>29,97</strong>/mês
        </p>
      </>
    );
  }