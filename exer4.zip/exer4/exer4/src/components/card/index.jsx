
import { Button } from "../button";

export function Card() {
  return (
    <>
    <Button />
      <Card />
      
    </>
  );
}
