export function Button() {
    return (
      <button type="button" id="botao">
        Assinar agora
      </button>
    );
  }